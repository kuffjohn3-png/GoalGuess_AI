#!/bin/bash

# GoalGuess Football Dashboard - Docker Deployment Script
# This script sets up Docker deployment even if Docker isn't pre-installed

echo "🐳 GoalGuess Football Dashboard - Docker Deployment"
echo "=================================================="

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run this script from project root."
    exit 1
fi

echo "✅ Project detected: GoalGuess Football Dashboard"

# Create environment file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "📝 Creating .env file from template..."
    cp .env.example .env
    echo "⚠️  Please edit .env file with your configuration before continuing!"
    echo "   Required: NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY, ZAI_API_KEY"
    read -p "Press Enter to continue after editing .env file: "
fi

# Function to install Docker if not available
install_docker_if_needed() {
    if ! command -v docker &> /dev/null; then
        echo "🐳 Docker not found. Installing Docker..."
        
        # Try different installation methods
        if command -v apt-get &> /dev/null; then
            echo "Installing Docker via apt-get..."
            curl -fsSL https://get.docker.com -o get-docker.sh
            sudo sh get-docker.sh
            sudo usermod -aG docker $USER
        elif command -v yum &> /dev/null; then
            echo "Installing Docker via yum..."
            sudo yum install -y yum-utils
            sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
            sudo yum install -y docker-ce docker-ce-cli containerd.io
            sudo usermod -aG docker $USER
        elif command -v brew &> /dev/null; then
            echo "Installing Docker via Homebrew..."
            brew install --cask docker
        else
            echo "❌ Cannot install Docker automatically. Please install Docker manually:"
            echo "   Ubuntu/Debian: curl -fsSL https://get.docker.com -o get-docker.sh && sudo sh get-docker.sh"
            echo "   CentOS/RHEL: yum install -y yum-utils && sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo && sudo yum install -y docker-ce"
            echo "   macOS: brew install --cask docker"
            exit 1
        fi
        
        # Start Docker service
        sudo systemctl start docker
        sudo systemctl enable docker
        
        echo "✅ Docker installed and started!"
        echo "🔄 Please log out and log back in to use Docker without sudo"
        echo "   Or run: newgrp docker && su - $USER"
    else
        echo "✅ Docker is already available!"
    fi
}

# Function to install Docker Compose if not available
install_docker_compose_if_needed() {
    if ! command -v docker-compose &> /dev/null; then
        echo "🐙 Installing Docker Compose..."
        
        if command -v apt-get &> /dev/null; then
            sudo apt-get update && sudo apt-get install -y docker-compose
        elif command -v yum &> /dev/null; then
            sudo yum install -y docker-compose
        elif command -v brew &> /dev/null; then
            brew install docker-compose
        else
            echo "❌ Cannot install Docker Compose automatically. Please install manually."
            exit 1
        fi
        
        echo "✅ Docker Compose installed!"
    else
        echo "✅ Docker Compose is already available!"
    fi
}

# Check deployment mode
echo ""
echo "🚀 Choose deployment mode:"
echo "1) Development (docker-compose.yml)"
echo "2) Production (docker-compose.prod.yml)"
echo "3) Build image only"
echo "4) Setup Docker environment only"
echo ""
read -p "Enter your choice (1-4): " mode

case $mode in
    1)
        echo "🔧 Setting up development environment..."
        compose_file="docker-compose.yml"
        ;;
    2)
        echo "🏭 Setting up production environment..."
        compose_file="docker-compose.prod.yml"
        ;;
    3)
        echo "📦 Building Docker image only..."
        install_docker_if_needed
        docker build -t goalguess:latest .
        echo "✅ Docker image built successfully!"
        echo "   Run with: docker run -p 3000:3000 goalguess:latest"
        exit 0
        ;;
    4)
        echo "🛠️  Setting up Docker environment..."
        install_docker_if_needed
        install_docker_compose_if_needed
        echo "✅ Docker environment is ready!"
        exit 0
        ;;
    *)
        echo "❌ Invalid choice"
        exit 1
        ;;
esac

# Install Docker and Docker Compose if needed
if [ "$mode" != "3" ]; then
    install_docker_if_needed
    install_docker_compose_if_needed
fi

# Create necessary directories
echo "📁 Creating necessary directories..."
mkdir -p ssl
mkdir -p logs

# Start containers
echo "🚀 Starting GoalGuess Football Dashboard with Docker Compose..."
echo "   Using: $compose_file"

if command -v docker-compose &> /dev/null; then
    docker-compose -f $compose_file up -d --build
else
    docker compose -f $compose_file up -d --build
fi

# Check if deployment was successful
if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 Deployment successful!"
    echo ""
    echo "🌐 Application is available at:"
    echo "   Local: http://localhost:3000"
    echo "   Health check: http://localhost:3000/api/health"
    echo ""
    echo "📋 Useful commands:"
    echo "   View logs: docker-compose -f $compose_file logs -f"
    echo "   Stop: docker-compose -f $compose_file down"
    echo "   Restart: docker-compose -f $compose_file restart"
    echo "   Scale: docker-compose -f $compose_file up -d --scale app=3"
    echo ""
    echo "🔍 Troubleshooting:"
    echo "   Check container status: docker-compose -f $compose_file ps"
    echo "   View resource usage: docker stats"
    echo "   Rebuild: docker-compose -f $compose_file up -d --build"
    echo ""
    echo "📊 Monitoring:"
    echo "   Health endpoint: curl http://localhost:3000/api/health"
    echo "   Application logs: docker-compose -f $compose_file logs -f app"
    echo "   Database logs: docker-compose -f $compose_file logs -f db"
    echo "   Redis logs: docker-compose -f $compose_file logs -f redis"
else
    echo "❌ Deployment failed. Please check the error messages above."
    exit 1
fi