'use client'

import { useState, useEffect, useRef } from 'react'
import dynamic from 'next/dynamic'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Trophy, 
  TrendingUp, 
  Users, 
  Calendar,
  Clock,
  MapPin,
  Target,
  Zap,
  Shield,
  Star,
  ChevronRight,
  Play,
  Pause,
  RefreshCw,
  BarChart3,
  Eye,
  ThumbsUp,
  ThumbsDown,
  Bell,
  History,
  CalendarDays,
  Home as HomeIcon,
  User,
  Tv,
  Award,
  Newspaper,
  Menu,
  X,
  ArrowUp,
  MessageSquare,
  Share2,
  Bookmark
} from 'lucide-react'

interface NewsArticle {
  id: string
  title: string
  summary: string
  content: string
  category: string
  source: string
  author: string
  publishedAt: string
  imageUrl?: string
  tags: string[]
  priority: 'breaking' | 'featured' | 'normal'
  relatedTeams?: string[]
  relatedLeagues?: string[]
}

interface Match {
  id: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  status: 'live' | 'finished' | 'upcoming'
  minute?: number
  league: string
  leagueFlag: string
  homeLogo?: string
  awayLogo?: string
  venue?: string
  attendance?: number
  prediction?: {
    winner: string
    confidence: number
    tips: string[]
    reasoning?: string
  }
  homeTeamStats?: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
  }
  awayTeamStats?: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
  }
  lastUpdate?: Date
}

interface Fixture {
  id: string
  homeTeam: string
  awayTeam: string
  date: string
  time: string
  league: string
  leagueFlag: string
  venue: string
  status: string
  matchday: string | number
  broadcast: string
  referee: string
}

interface PreviousGame {
  id: string
  homeTeam: string
  awayTeam: string
  homeScore: number
  awayScore: number
  date: string
  time: string
  league: string
  leagueFlag: string
  venue: string
  status: string
  matchday: string | number
  attendance: number
  homeTeamStats: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
    xG: number
    xGA: number
  }
  awayTeamStats: {
    possession: number
    shots: number
    shotsOnTarget: number
    corners: number
    fouls: number
    yellowCards: number
    redCards: number
    xG: number
    xGA: number
  }
  goalscorers: Array<{
    player: string
    team: string
    minute: number
    type: string
  }>
  manOfTheMatch: string
}

const initialMatches: Match[] = [
  {
    id: '1',
    homeTeam: 'Manchester City',
    awayTeam: 'Liverpool',
    homeScore: 2,
    awayScore: 1,
    status: 'live',
    minute: 67,
    league: 'Premier League',
    leagueFlag: '🏴󐁧󐁢󐁥󐁮󐁧󐁿',
    venue: 'Etihad Stadium',
    attendance: 55000,
    homeTeamStats: {
      possession: 62,
      shots: 14,
      shotsOnTarget: 6,
      corners: 7,
      fouls: 8,
      yellowCards: 1,
      redCards: 0
    },
    awayTeamStats: {
      possession: 38,
      shots: 8,
      shotsOnTarget: 3,
      corners: 3,
      fouls: 12,
      yellowCards: 2,
      redCards: 0
    }
  },
  {
    id: '2',
    homeTeam: 'Real Madrid',
    awayTeam: 'Barcelona',
    homeScore: 0,
    awayScore: 0,
    status: 'live',
    minute: 34,
    league: 'La Liga',
    leagueFlag: '🇪🇸',
    venue: 'Santiago Bernabéu',
    attendance: 80000,
    homeTeamStats: {
      possession: 55,
      shots: 9,
      shotsOnTarget: 2,
      corners: 4,
      fouls: 6,
      yellowCards: 1,
      redCards: 0
    },
    awayTeamStats: {
      possession: 45,
      shots: 7,
      shotsOnTarget: 2,
      corners: 2,
      fouls: 9,
      yellowCards: 2,
      redCards: 0
    }
  },
  {
    id: '3',
    homeTeam: 'Bayern Munich',
    awayTeam: 'Borussia Dortmund',
    homeScore: 3,
    awayScore: 2,
    status: 'finished',
    league: 'Bundesliga',
    leagueFlag: '🇩🇪',
    venue: 'Allianz Arena',
    attendance: 75000,
    homeTeamStats: {
      possession: 58,
      shots: 18,
      shotsOnTarget: 8,
      corners: 9,
      fouls: 10,
      yellowCards: 2,
      redCards: 0
    },
    awayTeamStats: {
      possession: 42,
      shots: 12,
      shotsOnTarget: 5,
      corners: 4,
      fouls: 14,
      yellowCards: 3,
      redCards: 1
    }
  },
  {
    id: '4',
    homeTeam: 'PSG',
    awayTeam: 'Marseille',
    homeScore: 0,
    awayScore: 0,
    status: 'upcoming',
    league: 'Ligue 1',
    leagueFlag: '🇫🇷',
    venue: 'Parc des Princes',
    attendance: 0
  }
]

export default function Home() {
  const [matches, setMatches] = useState<Match[]>(initialMatches)
  const [fixtures, setFixtures] = useState<Fixture[]>([])
  const [previousGames, setPreviousGames] = useState<PreviousGame[]>([])
  const [sportsNews, setSportsNews] = useState<NewsArticle[]>([])
  const [leagues, setLeagues] = useState<any[]>([])
  const [topScorers, setTopScorers] = useState<any[]>([])
  const [teamStats, setTeamStats] = useState<any[]>([])
  const [selectedTab, setSelectedTab] = useState('livescore')
  const [selectedLeague, setSelectedLeague] = useState('all')
  const [lastUpdate, setLastUpdate] = useState(new Date())
  const [loading, setLoading] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [notifications, setNotifications] = useState<string[]>([])
  const [showBottomNav, setShowBottomNav] = useState(true)
  const [isMobile, setIsMobile] = useState(false)
  const [isTablet, setIsTablet] = useState(false)
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null)
  const [showMatchDetails, setShowMatchDetails] = useState(false)

  useEffect(() => {
    fetchLeagues()
    fetchStats()
    fetchFixtures()
    fetchPreviousGames()
    fetchSportsNews()
    connectWebSocket()
    
    // Detect device type
    const detectDevice = () => {
      const width = window.innerWidth
      setIsMobile(width < 768)
      setIsTablet(width >= 768 && width < 1024)
      setShowBottomNav(width < 1024)
    }
    
    detectDevice()
    window.addEventListener('resize', detectDevice)
    
    return () => {
      window.removeEventListener('resize', detectDevice)
    }
  }, [])

  const fetchSportsNews = async () => {
    try {
      const response = await fetch('/api/sports-news?limit=6')
      const data = await response.json()
      if (data.success) {
        setSportsNews(data.articles || [])
      }
    } catch (error) {
      console.error('Failed to fetch sports news:', error)
    }
  }

  const connectWebSocket = () => {
    try {
      import('socket.io-client').then(({ io }) => {
        const socket = io('/?XTransformPort=3002')
        
        socket.on('connect', () => {
          console.log('Connected to WebSocket service')
          setIsConnected(true)
        })
        
        socket.on('disconnect', () => {
          console.log('Disconnected from WebSocket service')
          setIsConnected(false)
        })
        
        socket.on('matchUpdate', (updatedMatches: Match[]) => {
          setMatches(prevMatches => {
            const newMatches = prevMatches.map(match => {
              const updatedMatch = updatedMatches.find((um: Match) => um.id === match.id)
              return updatedMatch || match
            })
            return newMatches
          })
          setLastUpdate(new Date())
        })
        
        socket.on('goal', (data: any) => {
          const notification = `⚽ GOAL! ${data.team} scored! ${data.score} (${data.minute}')`
          setNotifications(prev => [notification, ...prev.slice(0, 4)])
        })
        
        socket.on('matchFinished', (data: any) => {
          const notification = `🏁 Match finished: ${data.finalScore} - Winner: ${data.winner}`
          setNotifications(prev => [notification, ...prev.slice(0, 4)])
        })
      })
    } catch (error) {
      console.error('Failed to connect to WebSocket:', error)
      setIsConnected(false)
    }
  }

  const fetchFixtures = async () => {
    try {
      const response = await fetch('/api/fixtures')
      const data = await response.json()
      if (data.success) {
        setFixtures(data.fixtures || [])
      }
    } catch (error) {
      console.error('Failed to fetch fixtures:', error)
    }
  }

  const fetchPreviousGames = async () => {
    try {
      const response = await fetch('/api/previous-games?type=recent')
      const data = await response.json()
      if (data.success) {
        setPreviousGames(data.games || [])
      }
    } catch (error) {
      console.error('Failed to fetch previous games:', error)
    }
  }

  const fetchLeagues = async () => {
    try {
      const response = await fetch('/api/leagues')
      const data = await response.json()
      if (data.success) {
        setLeagues(data.leagues || [])
      }
    } catch (error) {
      console.error('Failed to fetch leagues:', error)
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/stats')
      const data = await response.json()
      if (data.success) {
        setTopScorers(data.topScorers || [])
        setTeamStats(data.teamStats || [])
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error)
    }
  }

  const getStatusBadge = (status: string, minute?: number) => {
    switch (status) {
      case 'live':
        return (
          <Badge variant="destructive" className="animate-pulse">
            <Play className="w-3 h-3 mr-1" />
            LIVE {minute && `${minute}'`}
          </Badge>
        )
      case 'finished':
        return <Badge variant="secondary">FT</Badge>
      case 'upcoming':
        return <Badge variant="outline">UPCOMING</Badge>
      default:
        return null
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today'
    } else if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow'
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    }
  }

  const NewsArticleCard = ({ article }: { article: NewsArticle }) => (
    <Card className="hover:shadow-lg transition-shadow cursor-pointer">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant={article.priority === 'breaking' ? 'destructive' : article.priority === 'featured' ? 'default' : 'secondary'} className="text-xs">
                {article.priority.toUpperCase()}
              </Badge>
              <Badge variant="outline" className="text-xs">{article.category}</Badge>
            </div>
            <CardTitle className="text-lg line-clamp-2">{article.title}</CardTitle>
            <CardDescription className="text-sm line-clamp-2 mt-1">{article.summary}</CardDescription>
          </div>
          {article.imageUrl && (
            <div className="w-20 h-16 bg-muted rounded-lg flex-shrink-0">
              <img src={article.imageUrl} alt={article.title} className="w-full h-full object-cover rounded-lg" />
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between text-xs text-muted-foreground mb-3">
          <div className="flex items-center gap-2">
            <Newspaper className="w-3 h-3" />
            <span>{article.source}</span>
          </div>
          <div className="flex items-center gap-2">
            <User className="w-3 h-3" />
            <span>{article.author}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-3 h-3" />
            <span>{new Date(article.publishedAt).toLocaleDateString()}</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-1 mb-3">
          {article.tags.map((tag, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {tag}
            </Badge>
          ))}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <MessageSquare className="w-4 h-4 mr-2" />
            Read More
          </Button>
          <Button variant="ghost" size="sm">
            <Share2 className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="sm">
            <Bookmark className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )

  const MatchDetailsDialog = dynamic(() => import('@/components/MatchDetailsDialog'), {
    ssr: false,
    loading: () => (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-200"></div>
      </div>
    )
  })

  const handleMatchClick = (match: Match) => {
    setSelectedMatch(match)
    setShowMatchDetails(true)
  }

  const MatchCard = ({ match }: { match: Match }) => (
    <Card 
      className="hover:shadow-lg transition-shadow relative cursor-pointer"
      onClick={() => handleMatchClick(match)}
    >
      {match.status === 'live' && (
        <div className="absolute top-2 right-2">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
        </div>
      )}
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-lg">{match.leagueFlag}</span>
            <span className="text-sm font-medium text-muted-foreground">{match.league}</span>
          </div>
          {getStatusBadge(match.status, match.minute)}
        </div>
        {match.venue && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3" />
            {match.venue}
            {match.attendance && match.attendance > 0 && (
              <>
                <Separator orientation="vertical" className="h-3" />
                <Users className="w-3 h-3" />
                {match.attendance.toLocaleString()}
              </>
            )}
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{match.homeTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{match.homeTeam}</h3>
          </div>
          <div className="px-4">
            <div className="text-2xl font-bold text-center">
              {match.homeScore} - {match.awayScore}
            </div>
          </div>
          <div className="flex-1 text-center">
            <Avatar className="w-12 h-12 mx-auto mb-2">
              <AvatarFallback>{match.awayTeam.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <h3 className="font-semibold text-sm">{match.awayTeam}</h3>
          </div>
        </div>

        {match.status === 'live' && match.homeTeamStats && match.awayTeamStats && (
          <div className="grid grid-cols-2 gap-4 mb-4 p-3 bg-muted rounded-lg">
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>Possession</span>
                <span>{match.homeTeamStats.possession}%</span>
              </div>
              <Progress value={match.homeTeamStats.possession} className="h-1" />
              <div className="flex justify-between text-xs">
                <span>Shots</span>
                <span>{match.homeTeamStats.shots}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span>Corners</span>
                <span>{match.homeTeamStats.corners}</span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span>Possession</span>
                <span>{match.awayTeamStats.possession}%</span>
              </div>
              <Progress value={match.awayTeamStats.possession} className="h-1" />
              <div className="flex justify-between text-xs">
                <span>Shots</span>
                <span>{match.awayTeamStats.shots}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span>Corners</span>
                <span>{match.awayTeamStats.corners}</span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative w-8 h-8 md:w-10 md:h-10">
                <img
                  src="/logo.svg"
                  alt="GoalGuess AI Logo"
                  className="w-full h-full object-contain"
                />
              </div>
              <h1 className="text-xl font-bold">GoalGuess AI</h1>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm">
                <Bell className="w-4 h-4" />
                {notifications.length > 0 && (
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></div>
                )}
              </Button>
              <Button variant="ghost" size="sm">
                {isConnected ? (
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-xs">Connected</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-gray-500 rounded-full"></div>
                    <span className="text-xs">Disconnected</span>
                  </div>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold mb-2">Football Dashboard</h2>
            <p className="text-muted-foreground">AI-powered match predictions and live scores</p>
          </div>
          <div className="flex items-center gap-4">
            <Select value={selectedLeague} onValueChange={setSelectedLeague}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="All Leagues" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Leagues</SelectItem>
                {leagues.map((league: any) => (
                  <SelectItem key={league.id} value={league.id}>
                    {league.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="livescore">Live Score</TabsTrigger>
            <TabsTrigger value="fixtures">Fixtures</TabsTrigger>
            <TabsTrigger value="results">Results</TabsTrigger>
            <TabsTrigger value="stats">Statistics</TabsTrigger>
            <TabsTrigger value="news">News</TabsTrigger>
          </TabsList>

          <TabsContent value="livescore" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {matches.map((match) => (
                <MatchCard key={match.id} match={match} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="fixtures" className="space-y-6">
            <div className="text-center py-12">
              <p className="text-muted-foreground">Fixtures coming soon...</p>
            </div>
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {previousGames.map((game) => (
                <Card key={game.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{game.leagueFlag}</span>
                        <span className="text-sm font-medium text-muted-foreground">{game.league}</span>
                      </div>
                      <Badge variant="outline">{game.status}</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-center">
                        <h3 className="font-bold">{game.homeTeam}</h3>
                        <span className="text-2xl font-bold mx-2">{game.homeScore}</span>
                        <h3 className="font-bold">{game.awayTeam}</h3>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {formatDate(game.date)} • {game.time}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-4">
                      <div className="text-sm text-muted-foreground mb-2">
                        Venue: {game.venue} • Attendance: {game.attendance.toLocaleString()}
                      </div>
                      {game.goalscorers && game.goalscorers.length > 0 && (
                        <div className="space-y-2">
                          <h4 className="font-semibold mb-2">Goalscorers</h4>
                          {game.goalscorers.map((scorer, index) => (
                            <div key={index} className="flex items-center justify-between text-sm">
                              <span>{scorer.player} ({scorer.team})</span>
                              <span>{scorer.minute}' {scorer.type}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="stats" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Trophy className="w-5 h-5" />
                    Top Scorers
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topScorers.slice(0, 10).map((scorer, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="font-medium">{index + 1}. {scorer.name}</span>
                          <Badge variant="outline">{scorer.team}</Badge>
                        </div>
                        <div className="text-right">
                          <div className="font-bold">{scorer.goals}</div>
                          <div className="text-sm text-muted-foreground">goals</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5" />
                    Team Statistics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {teamStats.slice(0, 5).map((team, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded">
                        <div className="flex items-center gap-3">
                          <span className="font-medium">{team.name}</span>
                          <Badge variant="outline">{team.league}</Badge>
                        </div>
                        <div className="text-right">
                          <div className="font-bold">{team.points}</div>
                          <div className="text-sm text-muted-foreground">points</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="news" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {sportsNews.map((article) => (
                <NewsArticleCard key={article.id} article={article} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Bottom Navigation for Mobile */}
      {showBottomNav && (
        <div className="fixed bottom-0 left-0 right-0 bg-card border-t md:hidden">
          <div className="flex items-center justify-around py-2">
            <button
              onClick={() => setSelectedTab('livescore')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'livescore' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <Target className="w-5 h-5" />
              <span className="text-xs">Live</span>
            </button>
            <button
              onClick={() => setSelectedTab('fixtures')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'fixtures' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <Calendar className="w-5 h-5" />
              <span className="text-xs">Fixtures</span>
            </button>
            <button
              onClick={() => setSelectedTab('results')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'results' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <History className="w-5 h-5" />
              <span className="text-xs">Results</span>
            </button>
            <button
              onClick={() => setSelectedTab('stats')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'stats' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <BarChart3 className="w-5 h-5" />
              <span className="text-xs">Stats</span>
            </button>
            <button
              onClick={() => setSelectedTab('news')}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-colors ${
                selectedTab === 'news' ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
              }`}
            >
              <Newspaper className="w-5 h-5" />
              <span className="text-xs">News</span>
            </button>
          </div>
        </div>
      )}

      {/* Match Details Dialog */}
      {selectedMatch && (
        <MatchDetailsDialog
          match={selectedMatch}
          open={showMatchDetails}
          onOpenChange={setShowMatchDetails}
        />
      )}
    </div>
  )
}