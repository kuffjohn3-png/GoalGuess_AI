#!/bin/bash

# Vercel Deployment Script for GoalGuess Football Dashboard
# Pre-configured with your environment variables

echo "🚀 Deploying GoalGuess Football Dashboard to Vercel"
echo "=================================================="

# Check if we're in the right directory
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found. Please run this script from project root."
    exit 1
fi

echo "✅ Project detected: GoalGuess Football Dashboard"
echo "✅ Environment variables configured"

# Pre-build check
echo "🔧 Running pre-build checks..."

# Check if build works locally
echo "📦 Building application locally first..."
npm run build

if [ $? -ne 0 ]; then
    echo "❌ Build failed. Please fix the errors above before deploying."
    exit 1
fi

echo "✅ Local build successful!"

# Deploy using npx vercel
echo "🌐 Starting Vercel deployment..."
echo ""
echo "📋 Follow these steps in Vercel CLI:"
echo "1. Login to your Vercel account"
echo "2. Choose 'Link to existing project?' → No (first time)"
echo "3. Set project name: goalguess-ai"
echo "4. Set directory: . (current directory)"
echo "5. Override settings? → No"
echo "6. Connect to GitHub repository (recommended for auto-deploys)"
echo ""
echo "⚙️  Environment variables are pre-configured in .env.vercel"
echo "   Vercel will automatically use these during deployment"
echo ""

# Deploy with npx (no global install needed)
npx vercel --env-file .env.vercel

# Check deployment result
if [ $? -eq 0 ]; then
    echo ""
    echo "🎉 Deployment successful!"
    echo ""
    echo "🌟 Your GoalGuess AI Football Dashboard is live at:"
    echo "   🔗 https://goalguess-ai.vercel.app"
    echo ""
    echo "📊 Dashboard Features:"
    echo "   ✅ Live Football Scores with real-time updates"
    echo "   ✅ AI-Powered Match Predictions"
    echo "   ✅ Comprehensive Betting Markets"
    echo "   ✅ Advanced Statistics & Analytics"
    echo "   ✅ League Standings & Head-to-Head"
    echo "   ✅ Sports News Integration"
    echo "   ✅ Mobile-First Responsive Design"
    echo "   ✅ Dark Mode Support"
    echo ""
    echo "🔧 Next Steps:"
    echo "   1. Test all features at your live URL"
    echo "   2. Set up custom domain in Vercel dashboard"
    echo "   3. Configure analytics and monitoring"
    echo "   4. Connect GitHub repository for auto-deploys"
    echo ""
    echo "📞 Support & Documentation:"
    echo "   Vercel Dashboard: https://vercel.com/dashboard"
    echo "   Your Project: https://vercel.com/your-username/goalguess-ai"
    echo "   Build Logs: Check Vercel dashboard for deployment logs"
else
    echo "❌ Deployment failed. Please check the error messages above."
    echo ""
    echo "🔍 Troubleshooting:"
    echo "   1. Verify Vercel login: vercel whoami"
    echo "   2. Check environment variables in Vercel dashboard"
    echo "   3. Verify build logs in Vercel dashboard"
    echo "   4. Try manual deployment via Vercel web interface"
    exit 1
fi