# 🐳 GoalGuess Football Dashboard - Docker Deployment Guide

## 📋 Prerequisites

- Docker Engine 20.10+ and Docker Compose v2.0+
- Node.js 18+ (for local development)
- Git (for cloning)

---

## 🚀 Quick Start with Docker Compose

### **Step 1: Clone and Setup**
```bash
# Clone your repository
git clone <your-repo-url>
cd goalguess-football-dashboard

# Copy environment template
cp .env.example .env

# Edit environment variables
nano .env
```

### **Step 2: Environment Variables (.env)**
```bash
# App Configuration
NEXT_PUBLIC_APP_NAME=GoalGuess
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# AI Configuration
ZAI_API_KEY=your_z_ai_web_dev_sdk_key

# Optional: OpenAI (if using)
OPENAI_API_KEY=your_openai_key

# Database (if using PostgreSQL)
DATABASE_URL=postgresql://user:password@localhost:5432/goalguess
```

### **Step 3: Deploy with Docker Compose**
```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down

# Rebuild and restart
docker-compose up --build -d
```

---

## 🏗️ Production Deployment

### **Option 1: Docker Compose (Recommended)**
```bash
# Production docker-compose.yml
docker-compose -f docker-compose.prod.yml up -d
```

### **Option 2: Docker Standalone**
```bash
# Build image
docker build -t goalguess:latest .

# Run container
docker run -d \
  --name goalguess \
  -p 3000:3000 \
  --env-file .env \
  --restart unless-stopped \
  goalguess:latest
```

### **Option 3: Docker Swarm / Kubernetes**
```yaml
# Kubernetes deployment (k8s-deployment.yaml)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: goalguess
spec:
  replicas: 3
  selector:
    matchLabels:
      app: goalguess
  template:
    metadata:
      labels:
        app: goalguess
    spec:
      containers:
      - name: goalguess
        image: goalguess:latest
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        - name: NEXT_PUBLIC_APP_URL
          value: "https://your-domain.com"
```

---

## 🔧 Docker Configuration Files

### **Dockerfile** (Multi-stage build)
```dockerfile
# Build stage
FROM node:18-alpine AS deps
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production && npm cache clean --force

# Application stage
FROM node:18-alpine AS runner
WORKDIR /app

# Create non-root user
RUN addgroup --system --gid 1001 nodejs && \
    adduser --system --uid 1001 nextjs

# Copy dependencies and build
COPY --from=deps /app/node_modules ./node_modules
COPY --from=deps /app/.next ./.next
COPY . .

# Generate Prisma client
RUN npx prisma generate

# Build application
RUN npm run build

# Set permissions
RUN chown -R nextjs:nodejs /app
USER nextjs

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:3000/api/health || exit 1

EXPOSE 3000
ENV NODE_ENV=production
CMD ["node", ".next/standalone/server.js"]
```

### **docker-compose.yml** (Development)
```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=development
      - NEXT_PUBLIC_APP_URL=http://localhost:3000
      - NEXT_PUBLIC_SUPABASE_URL=${NEXT_PUBLIC_SUPABASE_URL}
      - NEXT_PUBLIC_SUPABASE_ANON_KEY=${NEXT_PUBLIC_SUPABASE_ANON_KEY}
      - ZAI_API_KEY=${ZAI_API_KEY}
    volumes:
      - .:/app
      - /app/node_modules
      - /app/.next
    depends_on:
      - redis
      - db
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped
    command: redis-server --appendonly yes

  db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_DB=goalguess
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=${DB_PASSWORD:-changeme}
      - POSTGRES_DB_USER=goalguess
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./init.sql:/docker-entrypoint-initdb.d/init.sql
    ports:
      - "5432:5432"
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - app
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:
```

### **docker-compose.prod.yml** (Production)
```yaml
version: '3.8'

services:
  app:
    build: 
      context: .
      dockerfile: Dockerfile.prod
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - NEXT_PUBLIC_APP_URL=${NEXT_PUBLIC_APP_URL}
      - NEXT_PUBLIC_SUPABASE_URL=${NEXT_PUBLIC_SUPABASE_URL}
      - NEXT_PUBLIC_SUPABASE_ANON_KEY=${NEXT_PUBLIC_SUPABASE_ANON_KEY}
      - ZAI_API_KEY=${ZAI_API_KEY}
    restart: unless-stopped
    deploy:
      replicas: 2
      resources:
        limits:
          cpus: '1.0'
          memory: 1G
        reservations:
          cpus: '0.5'
          memory: 512M
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/api/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.prod.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - app
    restart: unless-stopped

networks:
  default:
    driver: bridge
```

---

## 🌐 Nginx Configuration

### **nginx.prod.conf**
```nginx
events {
    worker_connections 1024;
}

http {
    upstream app {
        server app:3000;
    }

    # Rate limiting
    limit_req_zone $binary_remote_addr zone=limit:10m rate=10r/s;

    server {
        listen 80;
        server_name your-domain.com www.your-domain.com;
        
        # Redirect to HTTPS
        return 301 https://$server_name$request_uri;
    }

    server {
        listen 443 ssl http2;
        server_name your-domain.com www.your-domain.com;

        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:!aNULL:!MD5;

        # Security headers
        add_header X-Frame-Options "SAMEORIGIN" always;
        add_header X-XSS-Protection "1; mode=block" always;
        add_header X-Content-Type-Options "nosniff" always;
        add_header Referrer-Policy "no-referrer-when-downgrade" always;
        add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

        # Gzip compression
        gzip on;
        gzip_vary on;
        gzip_min_length 1024;
        gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

        # Rate limiting
        limit_req zone=limit burst=20 nodelay;

        location / {
            proxy_pass http://app;
            proxy_http_version 1.1;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection 'upgrade';
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_cache_bypass $http_upgrade;

            # Timeouts
            proxy_connect_timeout 60s;
            proxy_send_timeout 60s;
            proxy_read_timeout 60s;
        }

        # Static assets caching
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
            expires 1y;
            add_header Cache-Control "public, immutable";
        }
    }
}
```

---

## 🚀 Deployment Commands

### **Development**
```bash
# Start development environment
docker-compose up -d

# View logs
docker-compose logs -f app

# Stop development
docker-compose down
```

### **Production**
```bash
# Build and deploy production
docker-compose -f docker-compose.prod.yml up -d --build

# Scale application
docker-compose -f docker-compose.prod.yml up -d --scale app=3

# Update production
docker-compose -f docker-compose.prod.yml pull
docker-compose -f docker-compose.prod.yml up -d
```

### **Monitoring**
```bash
# Check container status
docker-compose ps

# View resource usage
docker stats

# Check logs
docker-compose logs -f

# Health check
curl http://localhost:3000/api/health
```

---

## 🔧 Environment Configuration

### **.env.example**
```bash
# Application
NEXT_PUBLIC_APP_NAME=GoalGuess
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

# AI Services
ZAI_API_KEY=your_z_ai_web_dev_sdk_key

# Optional: OpenAI
OPENAI_API_KEY=your_openai_key

# Database (if self-hosting)
DATABASE_URL=postgresql://postgres:changeme@localhost:5432/goalguess
DB_PASSWORD=your_secure_password

# Redis (if using)
REDIS_URL=redis://localhost:6379

# Production
NODE_ENV=production
PORT=3000
```

---

## 🚨 Production Considerations

### **Security**
- Use strong passwords for database
- Enable HTTPS with valid SSL certificates
- Set up firewall rules
- Use environment variables for secrets
- Enable rate limiting

### **Performance**
- Use nginx reverse proxy for static assets
- Enable Gzip compression
- Set up proper caching headers
- Use CDN for static assets
- Monitor resource usage

### **Monitoring**
- Set up health checks
- Monitor container logs
- Use application monitoring (Prometheus/Grafana)
- Set up alerting for failures
- Regular backup strategy

---

## 🎯 Deployment Checklist

- [ ] Docker and Docker Compose installed
- [ ] Environment variables configured
- [ ] SSL certificates obtained
- [ ] DNS records configured
- [ ] Firewall rules set
- [ ] Monitoring configured
- [ ] Backup strategy planned
- [ ] Health checks implemented
- [ ] Load balancing configured
- [ ] Domain name pointing to server

---

## 🚀 Quick Deploy Commands

```bash
# 1. Clone repository
git clone <your-repo-url> && cd goalguess-football-dashboard

# 2. Setup environment
cp .env.example .env
# Edit .env with your values

# 3. Deploy development
docker-compose up -d

# 4. Deploy production
docker-compose -f docker-compose.prod.yml up -d --build

# 5. Access application
open http://localhost:3000
# or
open https://your-domain.com
```

---

## 🎉 You're Ready!

Your GoalGuess Football Dashboard will be running in Docker containers with:
- ✅ **Application server** (Node.js)
- ✅ **Database** (PostgreSQL)
- ✅ **Cache** (Redis)
- ✅ **Reverse proxy** (Nginx)
- ✅ **SSL/TLS** encryption
- ✅ **Load balancing**
- ✅ **Health monitoring**

**Access your app at http://localhost:3000 or your configured domain!** 🚀